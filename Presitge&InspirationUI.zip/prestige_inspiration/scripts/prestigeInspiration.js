/*************************************************
 * META CURRENCY MANAGER (Inspiration & Prestige)
 * - Final Core Edition (Parity with Bruiser & Devil Fruit)
 * - Chat-Socket Audio Bypass (100% Sync for all Players & GM)
 * - GM-Only Master Volume & Audio FilePickers
 * - Public Announcements & Perfected Save State
 * - Ctrl+1 Global Keybind & Automatic Roll Reminders
 *************************************************/

const initMetaManager = async () => {
  const CFG = {
    SCOPE: "world",
    META_SCOPE: "curseMeta",
    BRUISER_KEY: "bruiserData",
    PREF_KEY: "metaManagerPrefs"
  };

  const INSPIRATION_TOOLTIP = `Inspiration: Standard (PHB) + House Variant\nAwarded by DM\nSpend for Advantage on attack/save/check\nShareable: can be gifted\nFlexible timing: before or after roll\nMust be declared immediately at the time of the roll or right after`;
  const PRESTIGE_TOOLTIP = `Prestige: Pirate Prestige Utility\nSpend on roleplay/exploration at DM discretion\nLocate Quests (1): find an NPC task in a populated area, no check (1/long rest)\nFind Minor Clue (1): DM hint if stuck (1/character/mission)\nRecruit Member (1): persuade an NPC to join your crew (GM details)\nGain Reputation (1): 24h rumors, gain 1 Reputation in a location\nLimit: once/character/location, max 5/crew/location\nRestriction: cannot be used if crew has only 1 Reputation there`;

  const clamp03 = (n) => Math.max(0, Math.min(3, Number(n ?? 0)));
  const getMetaKey = (type) => type === "inspiration" ? "Inspiration" : "Prestige";
  const getMetaTooltip = (type) => type === "inspiration" ? INSPIRATION_TOOLTIP : PRESTIGE_TOOLTIP;
  // Dynamically check the global setting to see if tooltips should be shown
  const tt = (str) => {
      try {
          if (game.settings.get("world", "metaManagerSettings").showTooltips === false) return "";
      } catch(e) {}
      return `title="${(str || "").replace(/\n/g, '&#10;')}"`;
  };
  const isManualClick = true;

  // ================= PREFS & PERSISTENT SETTINGS =================
  const getPrefs = () => {
      let p = game.user.getFlag(CFG.SCOPE, CFG.PREF_KEY) || {};
      if (!p.customColor) p.customColor = "#22d3ee";
      if (!p.uiScale) p.uiScale = 100;
      return p;
  };

  // Register a permanent, hidden world setting immune to flag wipes!
  if (!game.settings.settings.has("world.metaManagerSettings")) {
      game.settings.register("world", "metaManagerSettings", {
          name: "Meta Manager Settings",
          scope: "world",
          config: false,
          type: Object,
          default: {
              volume: 0.8,
              sndInspAdd: "sounds/lock.wav",
              sndInspRem: "sounds/lock.wav",
              sndPresAdd: "sounds/lock.wav",
              sndPresRem: "sounds/lock.wav",
              maxInsp: 3,
              maxPres: 3,
              showTooltips: true,
              showReputation: true, // Toggle for the Bar
              repValue: 5,          // Default Starting Rep
              maxRep: 100           // Default Colossal Island Max
          }
      });
  }

  const getGlobalSettings = () => game.settings.get("world", "metaManagerSettings");
  
  const setGlobalSettings = async (key, val) => {
      const current = getGlobalSettings();
      current[key] = val;
      await game.settings.set("world", "metaManagerSettings", current);
  };
  
  const makeCard = (title, desc, themeHex) => `<div style="border-radius:12px; padding:12px; margin:4px 0; background:radial-gradient(circle at top, #1e293b, #020617); border:2px solid ${themeHex}; box-shadow:0 0 10px ${themeHex}, inset 0 0 20px rgba(0,0,0,0.8); color:#e2e8f0; font-family:'Cinzel', serif;"><div style="font-size:20px; margin-bottom:8px; letter-spacing:1px; text-shadow:0 0 10px ${themeHex}; color:${themeHex}; border-bottom:1px solid rgba(255,255,255,0.1); padding-bottom:5px; text-align:center;">${title}</div><div style="font-size:13px; font-family:'Signika', sans-serif; color:#cbd5e1; line-height:1.4; text-align:left;">${desc}</div></div>`;

  const generateStandaloneHUD = async (a) => {
      const isCursed = a.items.some(i => i.type === "spell" && i.name.toLowerCase().includes("curse"));
      const isFruit = a.items.some(i => (i.type === "feat" && /devil fruit|devil-fruit|df\s*[-:]/i.test(i.name)) || (i.type === "spell" && i.system?.preparation?.mode === "innate"));
      
      let remindersHtml = "";
      if (isFruit) {
          const dfData = a.getFlag("world", "devilFruitCharges") || { current: 0, max: 0 };
          remindersHtml += `<a class="mcc-macro-btn" data-uuid="Macro.IDDYMqS11rGUUgoQ" data-actorid="${a.id}" style="display:block; border:1px solid #d8b4fe; background:rgba(168, 85, 247, 0.2); color:#e9d5ff; box-shadow:0 0 10px #a855f7; text-align:center; padding:6px; margin-bottom:6px; border-radius:4px; font-weight:bold; font-family:'Cinzel'; font-size:13px; cursor:pointer; text-decoration:none;">🍎 DEVIL FRUIT: ${dfData.current} / ${dfData.max} CHARGES</a>`;
      }
      if (isCursed) {
          const stage = a.getFlag("world", "curseStage") || 0;
          remindersHtml += `<a class="mcc-macro-btn" data-uuid="Macro.FsspzTmyEUgB1p7m" data-actorid="${a.id}" style="display:block; border:1px solid #fca5a5; background:rgba(239, 68, 68, 0.2); color:#fca5a5; box-shadow:0 0 10px #ef4444; text-align:center; padding:6px; margin-bottom:6px; border-radius:4px; font-weight:bold; font-family:'Cinzel'; font-size:13px; cursor:pointer; text-decoration:none;">☠️ CURSE STAGE: ${stage} ${stage > 0 ? "(Active)" : "(Inactive)"}</a>`;
      }
      
      return `<div class="mcc-neon-card" style="background: radial-gradient(circle at top, #1e293b, #020617); border: 2px solid #22c55e; border-radius: 12px; padding: 10px; margin-bottom: 8px; box-shadow: 0 0 10px rgba(34, 197, 94, 0.25); color: #e2e8f0; font-family: 'Cinzel', serif; text-align: center;">
          <div style="font-size:16px; text-transform:uppercase; letter-spacing:2px; font-weight:900; color:#fff; border:1px solid #fff; border-radius:4px; padding:4px; margin-bottom:10px; background:rgba(255,255,255,0.1); opacity:0.9;">TACTICAL HUD</div>
          ${remindersHtml}
          <div style="display:flex; border-bottom:1px solid rgba(255,255,255,0.1); padding:8px 0; align-items:flex-start;">
              <div style="flex:0 0 100px; font-weight:900; font-size:12px; text-align:right; padding-right:12px; color:#4ade80;">ACTION</div>
              <div style="flex:1; font-size:11px; text-align:left; color:#aaa; line-height:1.5; font-family:'Signika', sans-serif;">
                  <span title="Melee or Ranged Attack">Attack</span>, <span title="Cast a Spell with 1 Action">Cast</span>, <span title="Double your movement speed">Dash</span>, <span title="No Opportunity Attacks">Disengage</span>, <span title="Attacks vs you have Disadvantage">Dodge</span>, <span title="Grant Advantage">Help</span>, <span title="Stealth check">Hide</span>, <span title="Hold action">Ready</span>, <span title="Use object">Utilize</span>
              </div>
          </div>
          <div style="display:flex; border-bottom:1px solid rgba(255,255,255,0.1); padding:8px 0; align-items:flex-start;">
              <div style="flex:0 0 100px; font-weight:900; font-size:12px; text-align:right; padding-right:12px; color:#fbbf24;">BONUS</div>
              <div style="flex:1; font-size:11px; text-align:left; color:#aaa; line-height:1.5; font-family:'Signika', sans-serif;">
                  <span title="Light off-hand weapon">Off-Hand Pistol</span>, <span title="Unarmed Strike">Unarmed Strike</span>, <span title="Contested Athletics/Acrobatics">Contest Grapple</span>, <span title="Casting Time: 1 Bonus Action">Cast (BA)</span>, <span title="Drink Potion">Potion</span>
              </div>
          </div>
          <div style="display:flex; border-bottom:1px solid rgba(255,255,255,0.1); padding:8px 0; align-items:flex-start;">
              <div style="flex:0 0 100px; font-weight:900; font-size:12px; text-align:right; padding-right:12px; color:#ef4444;">REACTION</div>
              <div style="flex:1; font-size:11px; text-align:left; color:#aaa; line-height:1.5; font-family:'Signika', sans-serif;">
                  <span title="Enemy leaving reach">Opportunity</span>, <span title="Release Ready action">Trigger Ready</span>, <span title="Shield, Counterspell">Cast (R)</span>
              </div>
          </div>
          <div style="display:flex; border-bottom:1px solid rgba(255,255,255,0.1); padding:8px 0; align-items:flex-start;">
              <div style="flex:0 0 100px; font-weight:900; font-size:12px; text-align:right; padding-right:12px; color:#22d3ee;">FREE</div>
              <div style="flex:1; font-size:11px; text-align:left; color:#aaa; line-height:1.5; font-family:'Signika', sans-serif;">
                  <span title="Perception, Insight, etc.">Skill Check</span>, <span title="Draw weapon, open door">Interact</span>, <span title="Brief words">Speak</span>, <span title="Perception/Insight">Search</span>, <span title="Arcana/History">Study</span>, <span title="Persuasion/Intimidation">Influence</span>
              </div>
          </div>
          <div style="display:flex; border-bottom:1px solid rgba(255,255,255,0.1); padding:8px 0; align-items:flex-start;">
              <div style="flex:0 0 100px; font-weight:900; font-size:12px; text-align:right; padding-right:12px; color:#a8a29e;">MOVE</div>
              <div style="flex:1; font-size:11px; text-align:left; color:#aaa; line-height:1.5; font-family:'Signika', sans-serif;">
                  <span title="Movement speed">Position</span>, <span title="Half Movement">Stand Up</span>, <span title="Half Movement">Mount/Dismount</span>
              </div>
          </div>
          <div style="display:flex; padding:8px 0; align-items:flex-start; border-bottom:none; border-top:1px solid rgba(255,255,255,0.1); margin-top:4px; padding-top:8px;">
              <div style="flex:0 0 100px; font-weight:900; font-size:12px; text-align:right; padding-right:12px; color:#d8b4fe;">HOUSE</div>
              <div style="flex:1; font-size:11px; text-align:left; color:#aaa; line-height:1.5; font-family:'Signika', sans-serif; display:flex; justify-content:space-between; align-items:center;">
                  <span title="Once a day. Share a GIF to inspire!">Share GIF (+1d4)</span>
              </div>
          </div>
      </div>`;
  };

  // ================= 3-WAY SYNC LOGIC =================
  const ensureMetaFeature = async (a, name, tooltipText, preferredItemId, idPathToStore) => {
      if (!a) return null;
      const n = (name || "").toLowerCase();
      if (preferredItemId) {
          const byId = a.items.get(preferredItemId);
          if (byId && (byId.name || "").toLowerCase() === n && byId.type === "feat") return byId;
      }
      const candidates = a.items.filter(i => (i.name || "").toLowerCase() === n && i.type === "feat");
      let match = candidates[0] ?? null;
      if (match) {
          if (idPathToStore && a.isOwner) await a.update({ [idPathToStore]: match.id });
          return match;
      }
      if (!a.isOwner) return null;
      const descHtml = (tooltipText || "").replace(/\n/g, "<br>");
      
      // Creates item for reading rules ONLY (No double tracking on sheet)
      const data = { name, type: "feat", system: { description: { value: descHtml } } };
      const created = await a.createEmbeddedDocuments("Item", [data]);
      const item = created?.[0] ?? null;
      if (item && idPathToStore) await a.update({ [idPathToStore]: item.id });
      return item;
  };

  const readMetaValue = async (a) => {
      if (!a) return { insp: 0, pres: 0 };
      const meta = a.getFlag(CFG.SCOPE, CFG.META_SCOPE) || {};
      const gSets = getGlobalSettings();
      
      // Quietly ensure rulebook items exist on sheet with updated titles
      await ensureMetaFeature(a, "Inspiration (Ctrl+1)", getMetaTooltip("inspiration"), meta.inspItemId, `flags.${CFG.SCOPE}.${CFG.META_SCOPE}.inspItemId`);
      await ensureMetaFeature(a, "Prestige (Ctrl+1)", getMetaTooltip("prestige"), meta.presItemId, `flags.${CFG.SCOPE}.${CFG.META_SCOPE}.presItemId`);
      
      return { 
          insp: Math.max(0, Math.min(gSets.maxInsp, Number(meta.inspiration ?? 0))), 
          pres: Math.max(0, Math.min(gSets.maxPres, Number(meta.prestige ?? 0))) 
      };
  };

  const setMetaValue = async (a, type, next) => {
      if (!a || !a.isOwner) return null;
      const keyPath = type === "inspiration" ? `flags.${CFG.SCOPE}.${CFG.META_SCOPE}.inspiration` : `flags.${CFG.SCOPE}.${CFG.META_SCOPE}.prestige`;
      const bruiserPath = type === "inspiration" ? `flags.${CFG.SCOPE}.${CFG.BRUISER_KEY}.inspiration` : `flags.${CFG.SCOPE}.${CFG.BRUISER_KEY}.prestige`;
      await a.update({ [keyPath]: next, [bruiserPath]: next });
  };

  // ================= UI GENERATOR =================
  window.renderMetaManagerUI = async () => {
      const existingApp = Object.values(ui.windows).find(w => w.id === "meta-manager-ui");
      if (existingApp) { await existingApp.close(); }

      const prefs = getPrefs();
      const gSets = getGlobalSettings();
      const themeColor = prefs.customColor;
      const uiScale = prefs.uiScale;
      
      const actorsToManage = game.user.isGM 
          ? game.actors.filter(a => a.type === "character" && a.hasPlayerOwner)
          : [canvas.tokens.controlled[0]?.actor || game.user.character].filter(a => a);

      if (actorsToManage.length === 0) return ui.notifications.warn("No valid player characters found to manage.");

      const actorDataList = await Promise.all(actorsToManage.map(async a => {
          const vals = await readMetaValue(a);
          return { actor: a, insp: vals.insp, pres: vals.pres };
      }));

      const style = `<style>
          .br-dialog .window-content { background: radial-gradient(circle at top, #0f172a, #020617) !important; color: #e2e8f0; font-family: 'Signika', sans-serif; overflow: hidden !important; padding: 0 !important; }
          .mm-master-container { width: 100%; height: 100%; display: flex; flex-direction: column; }
          .mm-ui-wrapper { flex: 1; overflow-y: auto; padding: 10px; }
          .mm-ui-wrapper::-webkit-scrollbar { width: 6px; }
          .mm-ui-wrapper::-webkit-scrollbar-thumb { background: ${themeColor}; border-radius: 4px; }
          .br-group { border: 1px solid #334155; background: rgba(0,0,0,0.3); border-radius: 6px; padding: 12px; margin-bottom: 8px; }
          .br-btn-play { background: rgba(0,0,0,0.5) !important; color: ${themeColor} !important; border: 1px solid ${themeColor} !important; border-radius: 4px; cursor: pointer; display: flex; align-items: center; justify-content: center; transition: all 0.2s; }
          .br-btn-play:hover { background: ${themeColor} !important; color: #000 !important; box-shadow: 0 0 10px ${themeColor}; }
          .mm-actor-row { display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid rgba(255,255,255,0.1); padding:8px 0; }
          .mm-actor-row:last-child { border-bottom:none; }
          .mm-avatar { width:36px; height:36px; border-radius:4px; border:1px solid ${themeColor}; object-fit:cover; cursor:pointer; transition: 0.2s; }
          .mm-avatar:hover { box-shadow: 0 0 8px ${themeColor}; transform: scale(1.05); }
          .mm-ctrl-block { display:flex; flex-direction:column; align-items:center; cursor:help; }
          .mm-ctrl-label { font-size:11px; color:#94a3b8; font-weight:900; letter-spacing:1px; margin-bottom:4px; }
          .mm-ctrl-btns { display:flex; align-items:center; gap:6px; }
          .mm-val { font-family:'Cinzel', serif; font-size:16px; font-weight:bold; color:#fff; width:18px; text-align:center; }
          
          .br-footer { background: rgba(0,0,0,0.8); border-top: 1px solid ${themeColor}; padding: 8px 12px; display: flex; flex-direction: column; z-index: 10; }
          .br-footer-row { display: flex; justify-content: space-between; align-items: center; width: 100%; }
          .br-footer-group { display: flex; align-items: center; gap: 12px; }
          .st-footer-links { font-family: 'Signika', sans-serif; font-size: 11px; font-weight: bold; letter-spacing: 1px; color: #94a3b8; text-decoration: none; transition: all 0.2s ease; display: flex; align-items: center; gap: 4px; }
          .social-discord i, .social-discord .st-link-text { color: #5865F2; text-shadow: 0 0 5px #5865F2; }
          .social-discord:hover i, .social-discord:hover .st-link-text { text-shadow: 0 0 12px #5865F2; transform: scale(1.05); }
          .social-patreon i, .social-patreon .st-link-text { color: #FF424D; text-shadow: 0 0 5px #FF424D; }
          .social-patreon:hover i, .social-patreon:hover .st-link-text { text-shadow: 0 0 12px #FF424D; transform: scale(1.05); }
          .social-hud i, .social-hud .st-link-text { color: #22c55e; text-shadow: 0 0 5px #22c55e; }
          .social-hud:hover i, .social-hud:hover .st-link-text { text-shadow: 0 0 12px #22c55e; transform: scale(1.05); }
          
          .st-link-text { display: inline-block; }
          .st-settings-btn { font-size: 14px; color: #94a3b8; cursor: pointer; transition: all 0.2s ease; }
          .st-settings-btn:hover { color: ${themeColor}; transform: scale(1.1); text-shadow: 0 0 8px ${themeColor}; }
          .st-divider { width: 1px; height: 16px; background: rgba(255,255,255,0.2); margin: 0 4px; }
          .color-picker-input { width: 20px; height: 20px; padding: 0; border: 1px solid #334155; border-radius: 50%; cursor: pointer; background: transparent; }
          .color-picker-input::-webkit-color-swatch-wrapper { padding: 0; }
          .color-picker-input::-webkit-color-swatch { border: none; border-radius: 50%; }

          /* Reputation Slider Styling */
          #mm-rep-slider { -webkit-appearance: none; appearance: none; width: 100%; height: 6px; border-radius: 3px; background: #334155; outline: none; box-shadow: inset 0 0 5px rgba(0,0,0,0.8); margin-top: 4px; }
          #mm-rep-slider::-webkit-slider-runnable-track { height: 6px; border-radius: 3px; background: linear-gradient(to right, #fbbf24 var(--rep-pct, 0%), #334155 var(--rep-pct, 0%)); }
          #mm-rep-slider::-webkit-slider-thumb { -webkit-appearance: none; appearance: none; width: 12px; height: 12px; border-radius: 50%; background: #fff; cursor: pointer; box-shadow: 0 0 8px #fbbf24; margin-top: -3px; transition: transform 0.1s; }
          #mm-rep-slider::-webkit-slider-thumb:hover { transform: scale(1.2); }
          #mm-rep-slider:disabled::-webkit-slider-thumb { background: #94a3b8; box-shadow: 0 0 4px #94a3b8; cursor: default; }
          
          /* Dynamic Heartbeat Glow */
          @keyframes mm-heartbeat {
              0%   { transform: scale(1); text-shadow: 0 0 8px ${themeColor}; }
              15%  { transform: scale(1.15); text-shadow: 0 0 15px ${themeColor}, 0 0 25px ${themeColor}; color: #fff; }
              30%  { transform: scale(1); text-shadow: 0 0 8px ${themeColor}; }
              45%  { transform: scale(1.15); text-shadow: 0 0 15px ${themeColor}, 0 0 25px ${themeColor}; color: #fff; }
              60%, 100% { transform: scale(1); text-shadow: 0 0 8px ${themeColor}; }
          }
          .mm-heartbeat-text { animation: mm-heartbeat 2s infinite ease-in-out; display: inline-block; will-change: transform, text-shadow, color; }
      </style>`;

      let rowsHtml = actorDataList.map(data => `
          <div class="mm-actor-row">
              <div style="display:flex; align-items:center; gap:10px;">
                  <img src="${data.actor.img}" class="mm-avatar" data-id="${data.actor.id}" ${tt("Open Character Sheet")}>
                  <b style="color:#e2e8f0; font-size:14px;">${data.actor.name}</b>
              </div>
              <div style="display:flex; gap:16px;">
                  <div class="mm-ctrl-block" ${tt(INSPIRATION_TOOLTIP)}>
                      <span class="mm-ctrl-label">INSP</span>
                      <div class="mm-ctrl-btns">
                          <button class="br-btn-play mm-btn" data-type="inspiration" data-delta="-1" data-id="${data.actor.id}" style="width:24px; height:24px;"><i class="fas fa-minus"></i></button>
                          <span class="mm-val" id="insp-val-${data.actor.id}">${data.insp}</span>
                          <button class="br-btn-play mm-btn" data-type="inspiration" data-delta="1" data-id="${data.actor.id}" style="width:24px; height:24px;"><i class="fas fa-plus"></i></button>
                      </div>
                  </div>
                  <div class="mm-ctrl-block" ${tt(PRESTIGE_TOOLTIP)}>
                      <span class="mm-ctrl-label">PRES</span>
                      <div class="mm-ctrl-btns">
                          <button class="br-btn-play mm-btn" data-type="prestige" data-delta="-1" data-id="${data.actor.id}" style="width:24px; height:24px;"><i class="fas fa-minus"></i></button>
                          <span class="mm-val" id="pres-val-${data.actor.id}">${data.pres}</span>
                          <button class="br-btn-play mm-btn" data-type="prestige" data-delta="1" data-id="${data.actor.id}" style="width:24px; height:24px;"><i class="fas fa-plus"></i></button>
                      </div>
                  </div>
              </div>
          </div>
      `).join("");

      const content = `
          ${style}
          <div class="mm-master-container">
              <div class="mm-ui-wrapper">
                  <div class="br-group">${rowsHtml}</div>
              </div>
              
              ${gSets.showReputation !== false ? `
              <div style="padding: 0 12px 10px 12px;">
                  <div style="display:flex; justify-content:space-between; align-items:flex-end;">
                      <span style="font-family:'Cinzel', serif; font-size:13px; font-weight:900; color:#fbbf24; text-shadow:0 0 5px #fbbf24; letter-spacing:1px;">CREW REPUTATION</span>
                      <span id="mm-rep-display" style="font-family:'Signika', sans-serif; font-size:12px; font-weight:bold; color:#e2e8f0;">${gSets.repValue || 0} / ${gSets.maxRep || 100}</span>
                  </div>
                  <input type="range" id="mm-rep-slider" min="0" max="${gSets.maxRep || 100}" value="${gSets.repValue || 0}" ${game.user.isGM ? '' : 'disabled'} style="--rep-pct: ${((gSets.repValue || 0) / (gSets.maxRep || 100)) * 100}%" ${tt(game.user.isGM ? "Adjust the crew's reputation score on the current island." : "The crew's current reputation score.")}>
              </div>` : ''}

              <div class="br-footer">
                  <div class="br-footer-row">
                      <div class="br-footer-group" style="flex: 1; justify-content: flex-start;">
                          <a href="https://discord.gg/fBf7xw2bmB" target="_blank" class="st-footer-links social-discord" ${tt("Join the Developer Discord!")}><i class="fab fa-discord"></i> <span class="st-link-text">Discord</span></a>
                          <a href="https://www.patreon.com/Ctrl_Alt_Defeat" target="_blank" class="st-footer-links social-patreon" ${tt("Support the Creator on Patreon!")}><i class="fab fa-patreon"></i> <span class="st-link-text">Patreon</span></a>
                      </div>
                      
                      <div class="br-footer-group" style="flex: 0 0 auto; justify-content: center;">
                          <a id="mm-hud-btn" class="st-footer-links social-hud" style="cursor: pointer;" ${tt("Generate Tactical HUD")}><i class="fas fa-crosshairs"></i> <span class="st-link-text">HUD</span></a>
                      </div>

                      <div class="br-footer-group" style="flex: 1; justify-content: flex-end;">
                          <div class="mm-heartbeat-text" style="font-size: 10px; color: ${themeColor}; font-weight: bold; letter-spacing: 1px; cursor: help; transform-origin: center;" ${tt("You can press 'Ctrl+1' to toggle this window at any time.")}>Ctrl+1</div>
                          
                          <div class="st-divider"></div>

                          <input type="color" id="mm-color" class="color-picker-input" value="${themeColor}" ${tt("Change Theme Color")}>
                          <i class="fas fa-cog st-settings-btn mm-cog-btn" ${tt("Open Settings")}></i>
                      </div>
                  </div>
                  
                  <div id="mm-settings-panel" style="display: none; width: 100%; border-top: 1px dashed rgba(255,255,255,0.2); padding-top: 8px; margin-top: 8px; flex-direction: column; gap: 8px;">
                      <div style="display: flex; align-items: center; justify-content: space-between;" ${tt("Adjust the overall size of this window.")}>
                          <label style="font-size:11px; font-weight:bold; color:#cbd5e1;">UI Scale (<span id="mm-scale-val">${uiScale}%</span>)</label>
                          <input type="range" id="mm-scale-slider" min="60" max="140" step="5" value="${uiScale}" style="flex:1; margin-left:10px; cursor:pointer;">
                      </div>
                      
                      ${game.user.isGM ? `
                      <div style="width: 100%; height: 1px; background: rgba(255,255,255,0.1); margin: 2px 0;"></div>
                      <div style="display: flex; flex-direction: column; gap: 6px; font-family: 'Signika', sans-serif;">
                          
                          <div style="display: flex; gap: 6px;">
                              <div style="display: flex; align-items: center; justify-content: flex-start; gap: 4px; flex: 1;" ${tt("Maximum Inspiration a player can hold.")}>
                                  <label style="font-size:10px; color:#94a3b8; white-space: nowrap;">Max Insp:</label>
                                  <input type="number" class="mm-cap-input" data-key="maxInsp" value="${gSets.maxInsp}" min="1" max="99" style="width: 26px; height: 18px; font-size: 10px; background: rgba(0,0,0,0.5); border: 1px solid #334155; color: #cbd5e1; text-align: center; padding: 0;">
                              </div>
                              <div style="display: flex; align-items: center; justify-content: flex-start; gap: 4px; flex: 1;" ${tt("Maximum Prestige a player can hold.")}>
                                  <label style="font-size:10px; color:#94a3b8; white-space: nowrap;">Max Pres:</label>
                                  <input type="number" class="mm-cap-input" data-key="maxPres" value="${gSets.maxPres}" min="1" max="99" style="width: 26px; height: 18px; font-size: 10px; background: rgba(0,0,0,0.5); border: 1px solid #334155; color: #cbd5e1; text-align: center; padding: 0;">
                              </div>
                              <div style="display: flex; align-items: center; justify-content: flex-start; gap: 4px; flex: 1;" ${tt("Maximum Reputation for the current island.")}>
                                  <label style="font-size:10px; color:#94a3b8; white-space: nowrap;">Max Rep:</label>
                                  <input type="number" class="mm-cap-input" data-key="maxRep" value="${gSets.maxRep}" min="1" max="999" style="width: 30px; height: 18px; font-size: 10px; background: rgba(0,0,0,0.5); border: 1px solid #334155; color: #cbd5e1; text-align: center; padding: 0;">
                              </div>
                          </div>
                          
                          <div style="display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid rgba(255,255,255,0.05); padding-bottom: 6px;">
                              <label style="font-size:9px; color:#cbd5e1; cursor:pointer; display:flex; align-items:center; gap:4px;" ${tt("Toggle descriptive tooltips for UI elements.")}>
                                  <input type="checkbox" id="mm-toggle-tt" ${gSets.showTooltips !== false ? 'checked' : ''} style="margin:0; width:10px; height:10px;"> Show Hover Tooltips
                              </label>
                              <label style="font-size:9px; color:#cbd5e1; cursor:pointer; display:flex; align-items:center; gap:4px;" ${tt("Enable or disable the crew reputation tracker.")}>
                                  <input type="checkbox" id="mm-toggle-rep" ${gSets.showReputation !== false ? 'checked' : ''} style="margin:0; width:10px; height:10px;"> Show Reputation Bar
                              </label>
                          </div>
                          
                          <div style="display: flex; align-items: center; justify-content: space-between; gap: 4px; margin-top: 2px;" ${tt("Adjust the master volume for sound effects.")}>
                              <label style="font-size:10px; color:#94a3b8; width: 45px;">Volume:</label>
                              <input type="range" class="mm-audio-vol" min="0" max="1" step="0.05" value="${gSets.volume}" style="flex:1; cursor:pointer;">
                              <span id="mm-vol-val" style="font-size:10px; color:#cbd5e1; width:25px; text-align:right;">${Math.round(gSets.volume * 100)}%</span>
                          </div>
                          <div style="display: flex; align-items: center; justify-content: space-between; gap: 4px;" ${tt("Sound played when Inspiration is gained.")}>
                              <label style="font-size:10px; color:#94a3b8; width: 45px;">Insp (+):</label>
                              <div style="display: flex; flex: 1;">
                                  <input type="text" class="mm-snd-input" id="sndInspAdd" data-key="sndInspAdd" value="${gSets.sndInspAdd}" placeholder="Path..." style="flex:1; height: 18px; font-size: 10px; background: rgba(0,0,0,0.5); border: 1px solid #334155; color: #cbd5e1; padding-left: 4px;">
                                  <button type="button" class="file-picker mm-file-picker" data-type="audio" data-target="sndInspAdd" style="width:20px; height:18px; padding:0; line-height:1;"><i class="fas fa-file-audio"></i></button>
                              </div>
                          </div>
                          <div style="display: flex; align-items: center; justify-content: space-between; gap: 4px;" ${tt("Sound played when Inspiration is used.")}>
                              <label style="font-size:10px; color:#94a3b8; width: 45px;">Insp (-):</label>
                              <div style="display: flex; flex: 1;">
                                  <input type="text" class="mm-snd-input" id="sndInspRem" data-key="sndInspRem" value="${gSets.sndInspRem}" placeholder="Path..." style="flex:1; height: 18px; font-size: 10px; background: rgba(0,0,0,0.5); border: 1px solid #334155; color: #cbd5e1; padding-left: 4px;">
                                  <button type="button" class="file-picker mm-file-picker" data-type="audio" data-target="sndInspRem" style="width:20px; height:18px; padding:0; line-height:1;"><i class="fas fa-file-audio"></i></button>
                              </div>
                          </div>
                          <div style="display: flex; align-items: center; justify-content: space-between; gap: 4px;" ${tt("Sound played when Prestige is gained.")}>
                              <label style="font-size:10px; color:#94a3b8; width: 45px;">Pres (+):</label>
                              <div style="display: flex; flex: 1;">
                                  <input type="text" class="mm-snd-input" id="sndPresAdd" data-key="sndPresAdd" value="${gSets.sndPresAdd}" placeholder="Path..." style="flex:1; height: 18px; font-size: 10px; background: rgba(0,0,0,0.5); border: 1px solid #334155; color: #cbd5e1; padding-left: 4px;">
                                  <button type="button" class="file-picker mm-file-picker" data-type="audio" data-target="sndPresAdd" style="width:20px; height:18px; padding:0; line-height:1;"><i class="fas fa-file-audio"></i></button>
                              </div>
                          </div>
                          <div style="display: flex; align-items: center; justify-content: space-between; gap: 4px;" ${tt("Sound played when Prestige is used.")}>
                              <label style="font-size:10px; color:#94a3b8; width: 45px;">Pres (-):</label>
                              <div style="display: flex; flex: 1;">
                                  <input type="text" class="mm-snd-input" id="sndPresRem" data-key="sndPresRem" value="${gSets.sndPresRem}" placeholder="Path..." style="flex:1; height: 18px; font-size: 10px; background: rgba(0,0,0,0.5); border: 1px solid #334155; color: #cbd5e1; padding-left: 4px;">
                                  <button type="button" class="file-picker mm-file-picker" data-type="audio" data-target="sndPresRem" style="width:20px; height:18px; padding:0; line-height:1;"><i class="fas fa-file-audio"></i></button>
                              </div>
                          </div>
                      </div>
                      ` : ''}
                  </div>
              </div>
          </div>
      `;

      const dlgOpts = {
          id: "meta-manager-ui",
          classes: ["br-dialog"],
          width: 420 * (uiScale / 100), 
          height: "auto",
          resizable: false // Setting this to false permanently removes the bottom-right arrow
      };
      
      if (prefs.lastLeft) dlgOpts.left = prefs.lastLeft;
      if (prefs.lastTop)  dlgOpts.top = prefs.lastTop;

      const dlg = new Dialog({
          title: "Prestige & Inspiration UI CtrlAltDefeat",
          content: content,
          buttons: {},
          render: (html) => {
              html.closest('.window-content').css('zoom', `${uiScale}%`);
              
              const savePosition = async () => {
                  const app = Object.values(ui.windows).find(w => w.id === "meta-manager-ui");
                  if (app) {
                      prefs.lastLeft = app.position.left;
                      prefs.lastTop = app.position.top;
                      await game.user.setFlag(CFG.SCOPE, CFG.PREF_KEY, prefs);
                  }
              };
              
              setTimeout(() => {
                  html.closest('.app').find('.window-header').on('mouseup', savePosition);
              }, 100);

              html.find('.mm-avatar').click((e) => {
                  const id = $(e.currentTarget).data("id");
                  const a = game.actors.get(id);
                  if (a) a.sheet.render(true);
              });

              html.find('#mm-hud-btn').click(async (e) => {
                  e.preventDefault();
                  let targetActor = canvas.tokens.controlled[0]?.actor || game.user.character;
                  
                  if (!targetActor) {
                      ui.notifications.warn("Please select a token or assign a character to generate the HUD.");
                      return;
                  }
                  
                  const whisperTargets = game.user.isGM ? [] : [game.user.id];
                  const hudContent = await generateStandaloneHUD(targetActor);
                  
                  ChatMessage.create({
                      content: hudContent,
                      speaker: ChatMessage.getSpeaker({ actor: targetActor }),
                      whisper: whisperTargets
                  });
              });

              // --- GM ONLY: AUDIO LISTENERS & FILE PICKER ---
              if (game.user.isGM) {
                  html.find('#mm-toggle-tt').on('change', async function() {
                      await setGlobalSettings("showTooltips", this.checked);
                      window.renderMetaManagerUI(); // Instantly apply tooltip changes for the GM
                  });

                  html.find('#mm-toggle-rep').on('change', async function() {
                      await setGlobalSettings("showReputation", this.checked);
                      window.renderMetaManagerUI(); 
                  });

                  html.find('#mm-rep-slider').on('input change', async function(e) {
                      const val = parseInt($(this).val());
                      const max = parseInt($(this).attr('max'));
                      const pct = (val / max) * 100;
                      
                      // Updates visual instantly while dragging
                      $(this).css('--rep-pct', `${pct}%`);
                      html.find('#mm-rep-display').text(`${val} / ${max}`);
                      
                      // Saves to the permanent database only when the mouse is released
                      if (e.type === 'change') {
                          await setGlobalSettings("repValue", val);
                      }
                  });

                  html.find('.mm-cap-input').on('change', async function() {
                      const key = $(this).data('key');
                      await setGlobalSettings(key, parseInt($(this).val()));
                      window.renderMetaManagerUI(); 
                  });

                  html.find('.mm-audio-vol').on('input change', async function() {
                      const vol = parseFloat($(this).val());
                      html.find('#mm-vol-val').text(Math.round(vol * 100) + '%');
                      await setGlobalSettings("volume", vol);
                  });

                  html.find('.mm-file-picker').click(async (e) => {
                      e.preventDefault();
                      const button = e.currentTarget;
                      const targetInputId = button.dataset.target;
                      
                      new FilePicker({
                          type: "audio",
                          current: html.find(`#${targetInputId}`).val(),
                          callback: async (path) => {
                              const input = html.find(`#${targetInputId}`);
                              input.val(path);
                              await setGlobalSettings(targetInputId, path.trim());
                          }
                      }).render(true);
                  });

                  html.find('.mm-snd-input').on('change', async function() {
                      const key = $(this).data('key');
                      await setGlobalSettings(key, $(this).val().trim());
                  });
              }

              // --- SCALE SLIDER LOGIC ---
              const updateScale = async (newVal) => {
                  newVal = Math.max(60, Math.min(140, Number(newVal)));
                  html.find('#mm-scale-slider').val(newVal);
                  html.find('#mm-scale-val').text(newVal + '%');
                  html.closest('.window-content').css('zoom', newVal + '%');
                  
                  prefs.uiScale = newVal;
                  await game.user.setFlag(CFG.SCOPE, CFG.PREF_KEY, prefs);
                  
                  const app = Object.values(ui.windows).find(w => w.id === "meta-manager-ui");
                  if (app) {
                      app.setPosition({ width: 420 * (newVal / 100), height: "auto" });
                      savePosition(); 
                  }
              };

              html.find('#mm-scale-slider').on('input change', function() { updateScale($(this).val()); });

              html.find('.mm-cog-btn').click(() => {
                  const panel = html.find('#mm-settings-panel');
                  panel.slideToggle(200, () => {
                      const app = Object.values(ui.windows).find(w => w.id === "meta-manager-ui");
                      if (app) app.setPosition({ height: "auto" }); 
                  });
                  html.find('.mm-cog-btn').toggleClass('fa-spin');
              });
              
              html.find('#mm-color').on("change", async function() {
                  prefs.customColor = this.value;
                  await game.user.setFlag(CFG.SCOPE, CFG.PREF_KEY, prefs);
                  await savePosition(); 
                  window.renderMetaManagerUI();
              });

              // --- UPDATING VALUES & CROSS-PLAYER AUDIO SYNC ---
              html.find('.mm-btn').click(async (e) => {
                  const btn = $(e.currentTarget);
                  const type = btn.data("type");
                  const delta = parseInt(btn.data("delta"));
                  const a = game.actors.get(btn.data("id"));

                  if (!a) return;
                  const vals = await readMetaValue(a);
                  const gSets = getGlobalSettings();
                  const cur = type === "inspiration" ? vals.insp : vals.pres;
                  const cap = type === "inspiration" ? gSets.maxInsp : gSets.maxPres;
                  const next = Math.max(0, Math.min(cap, cur + delta));
                  if (cur === next) return;

                  await setMetaValue(a, type, next);
                  html.find(`#${type.substring(0,4)}-val-${a.id}`).text(next);

                  let soundPath = "";
                  if (type === "inspiration") {
                      soundPath = delta > 0 ? gSets.sndInspAdd : gSets.sndInspRem;
                  } else {
                      soundPath = delta > 0 ? gSets.sndPresAdd : gSets.sndPresRem;
                  }
                  const vol = gSets.volume ?? 0.8;

                  const label = getMetaKey(type);
                  const icon = type === "inspiration" ? "fa-sparkles" : "fa-crown";
                  const body = delta > 0 ? `<b>${a.name}</b> gained ${label}.` : `<b>${a.name}</b> used ${label}.`;
                  
                  // Broadcast the Chat Message PUBLICLY to everyone.
                  // By embedding the audio path into the flags, EVERY connected computer 
                  // intercepts it and plays it locally, bypassing player permission limits!
                  ChatMessage.create({
                      content: makeCard(`<i class="fas ${icon}"></i> ${label}`, body, themeColor),
                      speaker: ChatMessage.getSpeaker({ actor: a }),
                      whisper: [], // Empty array = Public Message
                      flags: { [CFG.SCOPE]: { metaAudio: soundPath, metaVol: vol } }
                  });
              });
          },
          close: async () => {
              const app = Object.values(ui.windows).find(w => w.id === "meta-manager-ui");
              if (app) {
                  prefs.lastLeft = app.position.left;
                  prefs.lastTop = app.position.top;
                  await game.user.setFlag(CFG.SCOPE, CFG.PREF_KEY, prefs);
              }
          }
      }, dlgOpts);
      
      dlg.render(true);
  };

  // ================= GLOBAL BINDINGS & HOOKS =================
  if (!window._metaManagerBound) {
      window._metaManagerBound = true;
      document.addEventListener("keydown", (e) => {
          if (e.ctrlKey && e.key === "1") {
              e.preventDefault();
              window.renderMetaManagerUI();
          }
      });
      console.log("Meta Manager bound to Ctrl+1");
  }

  if (!window._metaManagerHooks) {
      window._metaManagerHooks = true;
      
      const fireReminderCard = async (actor, title, extraText) => {
          if (!actor) return;
          const vals = await readMetaValue(actor);
          
          if (vals.insp > 0 || vals.pres > 0) {
              const themeColor = game.user.getFlag(CFG.SCOPE, CFG.PREF_KEY)?.customColor || "#22c55e";
              const content = makeCard(
                  title, 
                  `${extraText} Don't forget, you currently have <b>${vals.insp} Inspiration</b> and <b>${vals.pres} Prestige</b> available to use!<br><br><i style="color:#94a3b8;">Press <b>Ctrl+1</b> to open your Meta Manager.</i>`, 
                  themeColor
              );
              ChatMessage.create({
                  speaker: ChatMessage.getSpeaker({ actor }),
                  content: content,
                  whisper: [game.user.id] 
              });
          }
      };

      const loginReminder = async () => {
          const actor = game.user.character;
          if (!actor) return;
          
          await fireReminderCard(actor, "Welcome to the Session!", "Get ready to roll.");
      };
      
      if (!window._metaLoginFired) {
          window._metaLoginFired = true;
          loginReminder();
      }

      // THE GLOBAL AUDIO INTERCEPTOR
      Hooks.on("createChatMessage", async (msg) => {
          // 1. If this message contains our custom audio flag, play it!
          // Because this hook runs on every connected computer, everyone hears the sound simultaneously.
          const audioPath = msg.getFlag(CFG.SCOPE, "metaAudio");
          const audioVol = msg.getFlag(CFG.SCOPE, "metaVol");
          if (audioPath) {
              AudioHelper.play({ src: audioPath, volume: audioVol || 0.8, autoplay: true, loop: false }, false);
          }

          // 2. Roll Tracking Logic
          if (!msg.isAuthor) return;
          if (!msg.isRoll && (!msg.rolls || msg.rolls.length === 0)) return;

          const speaker = msg.speaker;
          if (!speaker || !speaker.actor) return;
          const actor = game.actors.get(speaker.actor);
          
          if (!actor || actor.type !== "character") return;

          let count = actor.getFlag(CFG.SCOPE, "metaReminderCount") || 0;
          count++;
          await actor.setFlag(CFG.SCOPE, "metaReminderCount", count);

          if (count % 4 === 0) {
              await fireReminderCard(actor, "Meta Currency Available!", "You are on a roll!");
          }
      });
  }

  // ================= EXECUTION =================
  // Execution removed here to prevent double-windows on load.
}; // End of initMetaManager

// --- UNIVERSAL LAUNCHER (Standalone Module Ready Hook) ---
// Ensures it works flawlessly as a standalone Module OR as a direct Macro click
if (game.ready) {
    initMetaManager();
    // Native manual popup execution for all users
    if (window.renderMetaManagerUI) window.renderMetaManagerUI();
} else {
    // wait for boot, then init and auto-pop for all players/GM.
    Hooks.once("ready", () => {
        initMetaManager();
        if (window.renderMetaManagerUI) window.renderMetaManagerUI();
    });
}